import SwiftUI

struct RootView: View {
    @State private var tab = 0
    var body: some View {
        NavigationSplitView {
            VStack(alignment: .leading, spacing: 8) {
                Label("総務経理ナビ", systemImage: "square.stack.3d.up.fill")
                    .font(.headline).padding(.horizontal, 12).padding(.vertical, 20)
                ForEach(0..<5) { index in
                    Button { tab = index } label: {
                        Label(["ホーム", "従業員", "給与", "経費", "契約"][index], systemImage: ["house", "person.2", "yensign.circle", "receipt", "doc.text"][index])
                            .font(.system(size: 15, weight: tab == index ? .semibold : .regular))
                            .frame(maxWidth: .infinity, alignment: .leading).padding(12)
                            .background(tab == index ? Color.teal.opacity(0.15) : Color.clear, in: RoundedRectangle(cornerRadius: 10))
                    }.buttonStyle(.plain).accessibilityIdentifier("navigation-\(index)")
                }
                Spacer()
                Text("毎日の事務を、ひとつに。")
                    .font(.caption).foregroundStyle(.secondary).padding(12)
            }.padding(12).navigationSplitViewColumnWidth(min: 180, ideal: 200, max: 240)
        } detail: {
            NavigationStack {
                switch tab {
                case 1: EmployeeListView()
                case 2: PayrollView()
                case 3: ExpenseListView()
                case 4: ContractListView()
                default: HomeView(tab: $tab)
                }
            }.id(tab)
        }.tint(.teal).frame(minWidth: 1000, minHeight: 740)

    }
}
struct MoneyField: View {
    let title: String
    @Binding var text: String
    var body: some View {
        HStack {
            Text(title)
            TextField("0", text: $text).labelsHidden().multilineTextAlignment(.trailing)
                .accessibilityLabel(title).accessibilityIdentifier(title)
        }
    }
}
struct FreeUsageView: View {
    @EnvironmentObject private var subscriptions: SubscriptionStore
    let title: String
    let count: Int
    @State private var showingPlans = false
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(subscriptions.isSubscribed ? "有料プラン・件数制限なし" : "無料枠：\(title) \(count) / 10件", systemImage: subscriptions.isSubscribed ? "checkmark.seal" : "gift")
                .font(.subheadline.bold())
            if !subscriptions.isSubscribed {
                Text("保存済み記録の閲覧・編集・削除は引き続き使えます。10件を超える新規登録には有料プランが必要です。")
                    .font(.caption).foregroundStyle(.secondary)
                Button("料金プランを見る") { showingPlans = true }.font(.subheadline)
            }
        }.sheet(isPresented: $showingPlans) { SubscriptionView() }
    }
}
struct ErrorNotice: ViewModifier {
    @Binding var message: String?
    func body(content: Content) -> some View {
        content.alert("保存できませんでした", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("閉じる", role: .cancel) { message = nil }
        } message: { Text(message ?? "") }
    }
}
extension View {
    func saveError(_ message: Binding<String?>) -> some View { modifier(ErrorNotice(message: message)) }
}
