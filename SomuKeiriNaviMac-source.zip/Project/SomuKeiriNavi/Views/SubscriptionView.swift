import SwiftUI
import StoreKit

struct SubscriptionView: View {
    @EnvironmentObject private var store: SubscriptionStore
    @Environment(\.dismiss) private var dismiss
    @State private var selectedID = SubscriptionStore.annualID
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 16) {
                        Image(systemName: "square.stack.3d.up.fill").font(.largeTitle).foregroundStyle(.mint)
                        Text("日々の事務を、\nまとめて管理。").font(.largeTitle.bold()).foregroundStyle(.white)
                        Text("従業員・給与の概算・経費・契約の基本情報を、端末内で整理するプランです。")
                            .foregroundStyle(.white.opacity(0.85))
                    }.padding(24).frame(maxWidth: .infinity, alignment: .leading)
                        .background(LinearGradient(colors: [Color(red: 0.06, green: 0.15, blue: 0.24), Color(red: 0.08, green: 0.29, blue: 0.33)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 24))
                    VStack(alignment: .leading, spacing: 8) {
                        Label("無料：各機能10件まで", systemImage: "gift")
                        Label("有料：登録件数の制限を解除", systemImage: "checkmark.circle")
                        Text("従業員・経費・給与記録・契約情報それぞれの保存件数です。解約後も記録は残ります。給与は概算で、税金・社会保険料は計算しません。契約書本文やPDF出力は含まれません。")
                            .font(.caption).foregroundStyle(.secondary)
                    }.padding(18).background(.background, in: RoundedRectangle(cornerRadius: 18))
                    Label(store.isSubscribed ? "定期購入は有効です" : "プランを選ぶ", systemImage: store.isSubscribed ? "checkmark.seal.fill" : "calendar").font(.title2.bold())
                    if store.isLoading { ProgressView("料金情報を取得中") }
                    ForEach(store.products, id: \.id) { product in
                        Button { selectedID = product.id } label: {
                            HStack(spacing: 16) {
                                Image(systemName: selectedID == product.id ? "checkmark.circle.fill" : "circle").font(.title2).foregroundStyle(.teal)
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(product.id == SubscriptionStore.annualID ? "年額プラン" : "月額プラン").font(.headline)
                                    Text(product.displayPrice + (product.id == SubscriptionStore.annualID ? " / 年" : " / 月")).font(.title2.bold())
                                    Text("自動更新・両プランの機能は同じです").font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer(minLength: 0)
                            }.padding(18).frame(maxWidth: .infinity, alignment: .leading)
                                .background(.background, in: RoundedRectangle(cornerRadius: 18))
                                .overlay(RoundedRectangle(cornerRadius: 18).stroke(selectedID == product.id ? .teal : .gray.opacity(0.2), lineWidth: 2))
                        }.buttonStyle(.plain).disabled(store.isPurchasing)
                    }
                    if store.products.isEmpty && !store.isLoading {
                        ContentUnavailableView("料金情報を取得できません", systemImage: "wifi.exclamationmark", description: Text(store.loadError ?? "準備中の商品は購入できません。通信環境を確認して再読み込みしてください。"))
                    }
                    if !store.isSubscribed, let selected = store.products.first(where: { $0.id == selectedID }) {
                        Button { Task { await store.purchase(selected) } } label: {
                            Text(store.isPurchasing ? "処理中…" : "\(selected.displayPrice)で\(selected.id == SubscriptionStore.annualID ? "年額" : "月額")プランを購入")
                                .font(.headline).frame(maxWidth: .infinity).padding(16)
                        }.buttonStyle(.borderedProminent).tint(.teal).disabled(store.isPurchasing)
                    }
                    HStack {
                        Button("購入を復元") { Task { await store.restore() } }
                        Spacer()
                        Button("再読み込み") { Task { await store.load() } }
                    }.disabled(store.isLoading || store.isPurchasing)
                    Link("定期購入の管理・解約", destination: URL(string: "https://apps.apple.com/account/subscriptions")!)
                    Text("お支払いはApple Accountに請求されます。定期購入は自動更新され、更新日の24時間前までに解約しない場合は次の期間の料金が請求されます。解約後も有効期間終了まで利用できます。端末内の記録は別の端末へ自動同期されません。")
                        .font(.caption).foregroundStyle(.secondary)
                    HStack {
                        Link("利用規約", destination: URL(string: "https://www.apple.com/legal/internet-services/itunes/dev/stdeula/")!)
                        Spacer()
                        Link("プライバシー", destination: URL(string: "https://github.com/sidebusiness1973-spec/somu-keiri-navi/blob/main/PRIVACY.md")!)
                    }.font(.caption)
                }.padding(20).frame(maxWidth: 700).frame(maxWidth: .infinity)
            }.background(Color(nsColor: .windowBackgroundColor)).navigationTitle("料金プラン")
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("閉じる") { dismiss() } } }
        }.frame(minWidth: 600, minHeight: 660).task { await store.load() }
            .alert("定期購入", isPresented: Binding(get: { store.message != nil }, set: { if !$0 { store.message = nil } })) {
                Button("閉じる", role: .cancel) { store.message = nil }
            } message: { Text(store.message ?? "") }
    }
}
