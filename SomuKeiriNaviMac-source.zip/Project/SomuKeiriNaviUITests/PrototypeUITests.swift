import XCTest
import StoreKitTest

final class PrototypeUITests: XCTestCase {
    @MainActor func testSubscriptionPurchaseRestoreAndExpiration() async throws {
        let configuration = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "SomuKeiriNavi", withExtension: "storekit"))
        let session = try SKTestSession(contentsOf: configuration)
        session.resetToDefaultState()
        session.clearTransactions()
        session.disableDialogs = true
        session.storefront = "JPN"
        defer { session.clearTransactions() }
        let app = XCUIApplication()
        app.launchArguments = ["--ui-testing"]
        for id in ["jp.prototype.somukeirinavi.v01.monthly", "jp.prototype.somukeirinavi.v01.annual"] {
            app.launch()
            XCTAssertTrue(app.buttons["navigation-0"].waitForExistence(timeout: 20))
            app.buttons["料金プラン"].click()
            let plan = app.buttons.matching(NSPredicate(format: "label CONTAINS %@", id.hasSuffix("annual") ? "年額プラン" : "月額プラン")).firstMatch
            if !plan.waitForExistence(timeout: 10) { app.scrollViews.firstMatch.scroll(byDeltaX: 0, deltaY: -500) }
            XCTAssertTrue(plan.waitForExistence(timeout: 10))
            plan.click()
            app.scrollViews.firstMatch.scroll(byDeltaX: 0, deltaY: -500)
            let purchase = app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "プランを購入")).firstMatch
            XCTAssertTrue(purchase.waitForExistence(timeout: 10))
            purchase.click()
            let active = app.staticTexts.matching(NSPredicate(format: "value CONTAINS %@ OR label CONTAINS %@", "定期購入は有効です", "定期購入は有効です")).firstMatch
            XCTAssertTrue(active.waitForExistence(timeout: 15))
            if app.buttons["action-button-1"].exists { app.buttons["action-button-1"].click() }
            app.terminate(); app.launch()
            app.buttons["料金プラン"].click()
            XCTAssertTrue(active.waitForExistence(timeout: 10))
            app.scrollViews.firstMatch.scroll(byDeltaX: 0, deltaY: -500)
            app.buttons["購入を復元"].click()
            XCTAssertTrue(active.waitForExistence(timeout: 10))
            try session.expireSubscription(productIdentifier: id)
            if app.buttons["action-button-1"].exists { app.buttons["action-button-1"].click() }
            app.terminate(); app.launch()
            app.buttons["料金プラン"].click()
            XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "value CONTAINS %@ OR label CONTAINS %@", "プランを選ぶ", "プランを選ぶ")).firstMatch.waitForExistence(timeout: 10))
            XCTAssertFalse(active.exists)
            session.clearTransactions()
            app.terminate()
        }
    }

    @MainActor func testExpenseFreeLimitAndEditing() throws {
        let app = XCUIApplication()
        app.launchArguments = ["--ui-testing"]
        app.launch()
        XCTAssertTrue(app.buttons["navigation-0"].waitForExistence(timeout: 20))
        app.buttons["navigation-3"].click()
        for index in 1...10 {
            app.buttons["追加"].click()
            let amount = app.textFields["金額（円）"]
            XCTAssertTrue(amount.waitForExistence(timeout: 5))
            amount.click(); amount.typeText("1200")
            let payee = app.textFields["expensePayee"]
            payee.click(); payee.typeText("Sample \(index)")
            let detail = app.textFields["expenseDetail"]
            detail.click(); detail.typeText("Train fare")
            app.buttons["保存"].click()
            XCTAssertTrue(app.buttons["追加"].waitForExistence(timeout: 5))
        }
        app.buttons["追加"].click()
        app.textFields["金額（円）"].click(); app.textFields["金額（円）"].typeText("900")
        app.textFields["expensePayee"].click(); app.textFields["expensePayee"].typeText("Blocked eleventh")
        app.textFields["expenseDetail"].click(); app.textFields["expenseDetail"].typeText("Sample")
        app.buttons["保存"].click()
        XCTAssertTrue(app.buttons["閉じる"].waitForExistence(timeout: 5))
        app.buttons["閉じる"].firstMatch.click()
        app.buttons["キャンセル"].click()
        let search = app.searchFields.firstMatch
        if !search.exists { app.scrollViews.firstMatch.scroll(byDeltaX: 0, deltaY: 500) }
        XCTAssertTrue(search.waitForExistence(timeout: 5))
        search.click(); search.typeText("Sample 10")
        let record = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "Sample 10、")).firstMatch
        XCTAssertTrue(record.waitForExistence(timeout: 5))
        record.click()
        XCTAssertTrue(app.buttons["保存"].waitForExistence(timeout: 5))
        // Saving an unchanged existing record must remain available at the free limit.
        app.buttons["保存"].click()
        XCTAssertTrue(app.buttons["追加"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.buttons["閉じる"].exists)
    }
    @MainActor func testPrototypeFlow() throws {
        let app = XCUIApplication()
        app.launchArguments = ["--ui-testing"]
        app.launch()
        XCTAssertTrue(app.buttons["navigation-0"].waitForExistence(timeout: 10))
        app.buttons["navigation-1"].click()
        app.buttons["追加"].click()
        let name = app.textFields["employeeName"]
        name.click(); name.typeText("Test Employee")
        let rate = app.textFields["基本給・時給（円）"]
        rate.click(); rate.typeKey("a", modifierFlags: .command); rate.typeText("300000")
        app.buttons["保存"].click()
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "Test Employee")).firstMatch.waitForExistence(timeout: 5))
        app.buttons["navigation-3"].click()
        app.buttons["追加"].click()
        let amount = app.textFields["金額（円）"]
        amount.click(); amount.typeText("1200")
        let payee = app.textFields["expensePayee"]
        payee.click(); payee.typeText("Test Store")
        let detail = app.textFields["expenseDetail"]
        detail.click(); detail.typeText("Train fare")
        app.buttons["保存"].click()
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "Test Store")).firstMatch.waitForExistence(timeout: 5))
        app.buttons["navigation-2"].click()
        app.scrollViews.firstMatch.scroll(byDeltaX: 0, deltaY: -500)
        XCTAssertTrue(app.buttons["計算結果を保存"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "value CONTAINS %@", "300,000")).firstMatch.exists)
        app.buttons["計算結果を保存"].click()
        XCTAssertTrue(app.sheets.firstMatch.waitForExistence(timeout: 5))
        app.buttons["OK"].click()
        app.buttons["navigation-4"].click()
        for title in ["業務委託契約書", "雇用契約書", "秘密保持契約書（NDA）", "簡易発注書"] {
            XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label CONTAINS %@", title)).firstMatch.exists)
        }
        app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "業務委託契約書")).firstMatch.click()
        let company = app.textFields["contractCompany"]
        XCTAssertTrue(company.waitForExistence(timeout: 5))
        company.click(); company.typeText("Test Company")
        let counterparty = app.textFields["contractCounterparty"]
        counterparty.click(); counterparty.typeText("Test Client")
        app.buttons["下書きを保存"].click()
        XCTAssertTrue(app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "Test Client")).firstMatch.waitForExistence(timeout: 5))
        app.buttons["navigation-0"].click()
        XCTAssertTrue(app.buttons["経費の記録をはじめる"].waitForExistence(timeout: 5))
    }
}
