import Foundation
import SwiftData

@Model final class Employee {
    @Attribute(.unique) var id: UUID
    var name: String
    var employmentType: String
    var payType: String
    var rate: Double
    var joinedAt: Date
    var memo: String
    init(name: String, employmentType: String, payType: String, rate: Double, joinedAt: Date, memo: String) {
        self.id = UUID(); self.name = name; self.employmentType = employmentType
        self.payType = payType; self.rate = rate; self.joinedAt = joinedAt; self.memo = memo
    }
}
@Model final class Expense {
    @Attribute(.unique) var id: UUID
    var date: Date
    var category: String
    var amount: Double
    var payee: String
    var detail: String
    var memo: String
    init(date: Date, category: String, amount: Double, payee: String, detail: String, memo: String) {
        self.id = UUID(); self.date = date; self.category = category; self.amount = amount
        self.payee = payee; self.detail = detail; self.memo = memo
    }
}
@Model final class Payroll {
    @Attribute(.unique) var id: UUID
    var employeeID: UUID
    var employeeName: String
    var month: Date
    var payType: String
    var rate: Double
    var hours: Double
    var overtime: Double
    var allowance: Double
    var deduction: Double
    var base: Double
    var overtimePay: Double
    var total: Double
    init(employee: Employee, month: Date, rate: Double, hours: Double, overtime: Double, allowance: Double, deduction: Double, result: PayrollResult) {
        id = UUID(); employeeID = employee.id; employeeName = employee.name; self.month = month
        payType = employee.payType; self.rate = rate; self.hours = hours; self.overtime = overtime
        self.allowance = allowance; self.deduction = deduction; base = result.base
        overtimePay = result.overtime; total = result.total
    }
}
@Model final class ContractDraft {
    @Attribute(.unique) var id: UUID
    var template: String
    var company: String
    var counterparty: String
    var start: Date
    var end: Date
    var amount: Double
    var detail: String
    init(template: String, company: String, counterparty: String, start: Date, end: Date, amount: Double, detail: String) {
        id = UUID(); self.template = template; self.company = company; self.counterparty = counterparty
        self.start = start; self.end = end; self.amount = amount; self.detail = detail
    }
}
