import SwiftUI

struct RootView: View {
    @State private var tab = 0
    var body: some View {
        TabView(selection: $tab) {
            NavigationStack { HomeView(tab: $tab) }.tabItem { Label("ホーム", systemImage: "house") }.tag(0)
            NavigationStack { EmployeeListView() }.tabItem { Label("従業員", systemImage: "person.2") }.tag(1)
            NavigationStack { PayrollView() }.tabItem { Label("給与", systemImage: "yensign.circle") }.tag(2)
            NavigationStack { ExpenseListView() }.tabItem { Label("経費", systemImage: "receipt") }.tag(3)
            NavigationStack { ContractListView() }.tabItem { Label("契約", systemImage: "doc.text") }.tag(4)
        }.tint(.teal)
    }
}
struct MoneyField: View {
    let title: String
    @Binding var text: String
    var body: some View {
        HStack {
            Text(title)
            TextField("0", text: $text).multilineTextAlignment(.trailing).keyboardType(.decimalPad)
                .accessibilityLabel(title).accessibilityIdentifier(title)
        }
    }
}
struct FreeUsageView: View {
    @EnvironmentObject private var subscriptions: SubscriptionStore
    let title: String
    let count: Int
    @State private var showingPlans = false
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(subscriptions.isSubscribed ? "有料プラン・件数制限なし" : "無料枠：\(title) \(count) / 10件", systemImage: subscriptions.isSubscribed ? "checkmark.seal" : "gift")
                .font(.subheadline.bold())
            if !subscriptions.isSubscribed {
                Text("保存済み記録の閲覧・編集・削除は引き続き使えます。10件を超える新規登録には有料プランが必要です。")
                    .font(.caption).foregroundStyle(.secondary)
                Button("料金プランを見る") { showingPlans = true }.font(.subheadline)
            }
        }.sheet(isPresented: $showingPlans) { SubscriptionView() }
    }
}
struct ErrorNotice: ViewModifier {
    @Binding var message: String?
    func body(content: Content) -> some View {
        content.alert("保存できませんでした", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) {
            Button("閉じる", role: .cancel) { message = nil }
        } message: { Text(message ?? "") }
    }
}
extension View {
    func saveError(_ message: Binding<String?>) -> some View { modifier(ErrorNotice(message: message)) }
}
