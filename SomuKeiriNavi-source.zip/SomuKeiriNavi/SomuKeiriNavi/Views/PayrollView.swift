import SwiftUI
import SwiftData

struct PayrollView: View {
    @EnvironmentObject private var subscriptions: SubscriptionStore
    @State private var showingPlans = false
    @Environment(\.modelContext) private var context

    @Query(sort: \Employee.name)
    private var employees: [Employee]

    @Query(sort: \Payroll.month, order: .reverse)
    private var payrolls: [Payroll]

    @State private var employeeID: UUID?
    @State private var month = Date()
    @State private var rate = "0"
    @State private var hours = "160"
    @State private var overtime = "0"
    @State private var allowance = "0"
    @State private var deduction = "0"
    @State private var error: String?
    @State private var saved = false
    @State private var deleting: Payroll?
    @State private var editingPayroll: Payroll?

    private var employee: Employee? {
        if let record = editingPayroll, record.employeeID == employeeID {
            let snapshot = Employee(name: record.employeeName, employmentType: "保存時の情報", payType: record.payType, rate: record.rate, joinedAt: record.month, memo: "")
            snapshot.id = record.employeeID
            return snapshot
        }
        return employees.first { $0.id == employeeID }
    }

    private var result: PayrollResult? {
        guard
            let employee,
            let rate = Input.number(rate),
            let hours = Input.number(hours),
            hours > 0,
            hours <= 744,
            let overtime = Input.number(overtime),
            overtime <= 744,
            let allowance = Input.number(allowance),
            let deduction = Input.number(deduction)
        else {
            return nil
        }

        return PayrollCalculator.calculate(
            monthly: employee.payType == "月給",
            rate: rate,
            hours: hours,
            overtime: overtime,
            allowance: allowance,
            deduction: deduction
        )
    }

    var body: some View {
        Form {
            Section { FreeUsageView(title: "給与記録", count: payrolls.count) }
            Section {
                Text(
                    "この計算は概算であり、正式な給与計算を保証するものではありません。税金・社会保険料は計算しません。"
                )
                .font(.footnote)
                .foregroundStyle(.secondary)
            }

            if employees.isEmpty && editingPayroll == nil {
                ContentUnavailableView(
                    "従業員の登録が必要です",
                    systemImage: "person.badge.plus",
                    description: Text("「従業員」タブで登録してください。")
                )
            } else {
                Section("計算条件") {
                    Picker("従業員", selection: $employeeID) {
                        Text("選択してください")
                            .tag(nil as UUID?)

                        if let record = editingPayroll, !employees.contains(where: { $0.id == record.employeeID }) {
                            Text(record.employeeName + "（保存時の情報）").tag(Optional(record.employeeID))
                        }
                        ForEach(employees) { employee in
                            Text(employee.name)
                                .tag(Optional(employee.id))
                        }
                    }
                    .accessibilityIdentifier("payrollEmployee")

                    DatePicker(
                        "対象月（日付の月を使用）",
                        selection: $month,
                        displayedComponents: .date
                    )

                    if let employee {
                        LabeledContent(
                            "給与区分",
                            value: employee.payType
                        )
                    }

                    MoneyField(
                        title: "基本給・時給（円）",
                        text: $rate
                    )

                    MoneyField(
                        title: "勤務時間（時間）",
                        text: $hours
                    )

                    MoneyField(
                        title: "残業時間（時間）",
                        text: $overtime
                    )

                    MoneyField(
                        title: "各種手当（円）",
                        text: $allowance
                    )

                    MoneyField(
                        title: "その他控除（円）",
                        text: $deduction
                    )
                }

                Section {
                    Text(
                        "時給：時給 × 勤務時間。月給：基本給をそのまま使用し、勤務時間は月の所定労働時間として入力してください。残業は通常勤務時間に含めず、時間単価 × 残業時間 × 1.25で試算します。端数は残業分のみ円単位に四捨五入します。"
                    )
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }

                if let result {
                    Section {
                        LabeledContent(
                            "基本給与",
                            value: result.base.yen
                        )

                        LabeledContent(
                            "残業分",
                            value: result.overtime.yen
                        )

                        LabeledContent(
                            "手当",
                            value: result.allowance.yen
                        )

                        LabeledContent(
                            "控除",
                            value: result.deduction.yen
                        )

                        LabeledContent(
                            "支給予定額",
                            value: result.total.yen
                        )
                        .font(.headline)
                        .accessibilityIdentifier("payrollTotal")

                        if result.total < 0 {
                            Text(
                                "控除が支給額を上回っています。入力を確認してください。"
                            )
                            .foregroundStyle(.red)
                        }

                        Button("計算結果を保存") {
                            save(result)
                        }
                        .disabled(result.total < 0)

                    } header: {
                        Text("計算結果（自動更新）")

                    } footer: {
                        Text(
                            "同じ従業員・対象月の保存結果は置き換わります。ホームの給与予定額にも反映されます。"
                        )
                    }
                } else {
                    Text(
                        "従業員を選択し、金額と時間を入力してください。勤務時間は0より大きく、744以下にしてください。"
                    )
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                }
            }

            if !payrolls.isEmpty {
                Section("保存済みの給与予定") {
                    ForEach(payrolls) { payroll in
                        VStack(alignment: .leading) {
                            HStack {
                                Text(payroll.employeeName)

                                Spacer()

                                Text(payroll.total.yen)
                                    .bold()
                            }

                            Text(
                                payroll.month,
                                format: .dateTime.year().month()
                            )
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            Button("この記録を編集") {
                                    editingPayroll = payroll
                                    employeeID = payroll.employeeID; month = payroll.month
                                    rate = String(payroll.rate); hours = String(payroll.hours)
                                    overtime = String(payroll.overtime); allowance = String(payroll.allowance)
                                    deduction = String(payroll.deduction)
                            }
                        }.swipeActions { Button("削除", role: .destructive) { deleting = payroll } }
                    }
                }
            }
        }
        .navigationTitle("給与計算")
        .confirmationDialog("この給与記録を削除しますか？", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
            Button("削除", role: .destructive) {
                guard let record = deleting else { return }
                do { try RecordService.delete(record, from: context) } catch { self.error = error.localizedDescription }
                deleting = nil
            }
            Button("キャンセル", role: .cancel) { deleting = nil }
        }
        .onChange(of: employeeID) { _, _ in
            if editingPayroll?.employeeID != employeeID {
                editingPayroll = nil
                if let employee { rate = String(employee.rate) }
            }
        }
        .onAppear {
            if employeeID == nil {
                employeeID = employees.first?.id
            }
        }
        .alert(
            "計算結果を保存しました",
            isPresented: $saved
        ) {
            Button("OK", role: .cancel) {}
        }
        .saveError($error)
        .sheet(isPresented: $showingPlans) { SubscriptionView() }
    }

    private func save(_ result: PayrollResult) {
        guard let employee else {
            return
        }

        let replacing = payrolls.contains { $0.employeeID == employee.id && Calendar.current.isDate($0.month, equalTo: month, toGranularity: .month) }
        guard replacing || subscriptions.canAdd(count: payrolls.count) else { showingPlans = true; return }
        do {
            let record = Payroll(
                employee: employee,
                month: month,
                rate: Input.number(rate) ?? 0,
                hours: Input.number(hours) ?? 0,
                overtime: Input.number(overtime) ?? 0,
                allowance: result.allowance,
                deduction: result.deduction,
                result: result
            )

            try RecordService.savePayroll(
                record,
                existing: payrolls,
                context: context
            )

            saved = true

        } catch {
            self.error = error.localizedDescription
        }
    }
}
