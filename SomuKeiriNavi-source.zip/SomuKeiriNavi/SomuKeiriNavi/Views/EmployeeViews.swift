import SwiftUI
import SwiftData

struct EmployeeListView: View {
    @Environment(\.modelContext) private var context
    @Query(sort: \Employee.name) private var employees: [Employee]
    @State private var adding = false
    @State private var deleting: Employee?
    @State private var error: String?
    var body: some View {
        List {
            Section { FreeUsageView(title: "従業員", count: employees.count) }
            if employees.isEmpty {
                ContentUnavailableView("従業員を登録しましょう", systemImage: "person.2", description: Text("右上の「追加」から登録できます。"))
            }
            ForEach(employees) { employee in
                NavigationLink { EmployeeForm(employee: employee) } label: {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(employee.name).font(.headline)
                        Text("\(employee.employmentType) · \(employee.payType) \(employee.rate.yen)").font(.subheadline).foregroundStyle(.secondary)
                    }
                }.swipeActions { Button("削除", role: .destructive) { deleting = employee } }
            }
        }.navigationTitle("従業員管理")
            .toolbar { Button("追加", systemImage: "plus") { adding = true } }
            .sheet(isPresented: $adding) { NavigationStack { EmployeeForm() } }
            .alert("従業員を削除しますか？", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } })) {
                Button("削除", role: .destructive) {
                    if let deleting { do { try RecordService.delete(deleting, from: context) } catch { self.error = error.localizedDescription } }
                    deleting = nil
                }
                Button("キャンセル", role: .cancel) { deleting = nil }
            } message: { Text("保存済みの給与計算結果は履歴として残ります。") }
            .saveError($error)
    }
}
struct EmployeeForm: View {
    @EnvironmentObject private var subscriptions: SubscriptionStore
    @Query private var allRecords: [Employee]
    @State private var showingPlans = false
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    var employee: Employee?
    @State private var name = ""
    @State private var type = "正社員"
    @State private var payType = "月給"
    @State private var rate = ""
    @State private var joined = Date()
    @State private var memo = ""
    @State private var loaded = false
    @State private var error: String?
    var body: some View {
        Form {
            Section("基本情報") {
                TextField("氏名（必須）", text: $name).accessibilityIdentifier("employeeName")
                Picker("雇用形態", selection: $type) { ForEach(["正社員", "契約社員", "パート・アルバイト", "役員", "その他"], id: \.self) { Text($0) } }
                DatePicker("入社日", selection: $joined, displayedComponents: .date)
            }
            Section("給与の設定") {
                Picker("給与区分", selection: $payType) { Text("月給").tag("月給"); Text("時給").tag("時給") }.pickerStyle(.segmented)
                MoneyField(title: "基本給・時給（円）", text: $rate)
            }
            Section("メモ") { TextField("メモ", text: $memo, axis: .vertical).lineLimit(3...6) }
        }.navigationTitle(employee == nil ? "従業員を登録" : "従業員を編集")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("キャンセル") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("保存", action: save).disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || Input.number(rate) == nil) }
            }.onAppear {
                guard !loaded else { return }; loaded = true
                if let employee { name = employee.name; type = employee.employmentType; payType = employee.payType; rate = String(employee.rate); joined = employee.joinedAt; memo = employee.memo }
            }.saveError($error).sheet(isPresented: $showingPlans) { SubscriptionView() }
    }
    private func save() {
        guard let amount = Input.number(rate) else { return }
        guard employee != nil || subscriptions.canAdd(count: allRecords.count) else { showingPlans = true; return }
        do {
            let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
            if let employee {
                employee.name = cleanName; employee.employmentType = type; employee.payType = payType
                employee.rate = amount; employee.joinedAt = joined; employee.memo = memo
                try RecordService.save(context)
            } else {
                try RecordService.add(Employee(name: cleanName, employmentType: type, payType: payType, rate: amount, joinedAt: joined, memo: memo), to: context)
            }
            dismiss()
        } catch { self.error = error.localizedDescription }
    }
}
