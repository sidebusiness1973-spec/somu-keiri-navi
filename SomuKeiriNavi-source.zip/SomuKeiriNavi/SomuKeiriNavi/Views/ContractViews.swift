import SwiftUI
import SwiftData

struct ContractListView: View {
    @Environment(\.modelContext) private var context
    @State private var deleting: ContractDraft?
    @State private var error: String?
    @Query(sort: \ContractDraft.start, order: .reverse) private var drafts: [ContractDraft]
    private let templates = ["業務委託契約書", "雇用契約書", "秘密保持契約書（NDA）", "簡易発注書"]
    var body: some View {
        List {
            Section { FreeUsageView(title: "契約情報", count: drafts.count) }
            Section { Text("テンプレートを選び、契約情報の下書きを保存できます。本文の自動生成・PDF化は次バージョンで対応予定です。").font(.subheadline).foregroundStyle(.secondary) }
            Section("テンプレートを選択") {
                ForEach(templates, id: \.self) { template in
                    NavigationLink { ContractForm(template: template) } label: { Label(template, systemImage: "doc.text") }
                }
            }
            if !drafts.isEmpty {
                Section("保存した下書き") {
                    ForEach(drafts) { draft in
                        NavigationLink { ContractForm(template: draft.template, draft: draft) } label: {
                            VStack(alignment: .leading) { Text(draft.counterparty).font(.headline); Text(draft.template).font(.caption).foregroundStyle(.secondary) }
                        }.swipeActions { Button("削除", role: .destructive) { deleting = draft } }
                    }
                }
            }
        }.navigationTitle("契約情報")
            .confirmationDialog("この契約情報を削除しますか？", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible) {
                Button("削除", role: .destructive) {
                    guard let record = deleting else { return }
                    do { try RecordService.delete(record, from: context) } catch { self.error = error.localizedDescription }
                    deleting = nil
                }
                Button("キャンセル", role: .cancel) { deleting = nil }
            }.saveError($error)
    }
}
struct ContractForm: View {
    @EnvironmentObject private var subscriptions: SubscriptionStore
    @Query private var allRecords: [ContractDraft]
    @State private var showingPlans = false
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    let template: String
    var draft: ContractDraft?
    @State private var company = ""
    @State private var counterparty = ""
    @State private var start = Date()
    @State private var end = Date()
    @State private var amount = "0"
    @State private var detail = ""
    @State private var loaded = false
    @State private var error: String?
    var body: some View {
        Form {
            Section("契約の基本情報") {
                TextField("会社名（必須）", text: $company)
                TextField("相手方名称（必須）", text: $counterparty)
                DatePicker("契約開始日", selection: $start, displayedComponents: .date)
                DatePicker("契約終了日", selection: $end, displayedComponents: .date)
                MoneyField(title: "契約金額（円）", text: $amount)
                if end < start { Text("終了日は開始日以降にしてください。").foregroundStyle(.red) }
            }
            Section("業務内容・契約の対象") { TextField("業務内容などを入力", text: $detail, axis: .vertical).lineLimit(4...10) }
            Section { Text("この下書きは契約書本文ではありません。金額のない契約は0円で保存できます。").font(.footnote).foregroundStyle(.secondary) }
            Button("下書きを保存", action: save).disabled(company.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || counterparty.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || Input.number(amount) == nil || end < start)
        }.navigationTitle(template).navigationBarTitleDisplayMode(.inline)
            .onAppear {
                guard !loaded else { return }; loaded = true
                if let draft { company = draft.company; counterparty = draft.counterparty; start = draft.start; end = draft.end; amount = String(draft.amount); detail = draft.detail }
            }.saveError($error).sheet(isPresented: $showingPlans) { SubscriptionView() }
    }
    private func save() {
        guard let amount = Input.number(amount) else { return }
        guard draft != nil || subscriptions.canAdd(count: allRecords.count) else { showingPlans = true; return }
        do {
            if let draft {
                draft.company = company; draft.counterparty = counterparty; draft.start = start; draft.end = end; draft.amount = amount; draft.detail = detail
                try RecordService.save(context)
            } else {
                try RecordService.add(ContractDraft(template: template, company: company, counterparty: counterparty, start: start, end: end, amount: amount, detail: detail), to: context)
            }
            dismiss()
        } catch { self.error = error.localizedDescription }
    }
}
