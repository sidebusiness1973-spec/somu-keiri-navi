import SwiftUI
import SwiftData

struct ExpenseListView: View {
    @Environment(\.modelContext) private var context
    @Query(sort: \Expense.date, order: .reverse) private var expenses: [Expense]
    @State private var adding = false
    @State private var query = ""
    @State private var selectedMonth = Date()
    @State private var allMonths = false
    @State private var pendingDelete: Expense?
    @State private var error: String?
    private var filtered: [Expense] {
        expenses.filter { item in
            (allMonths || Calendar.current.isDate(item.date, equalTo: selectedMonth, toGranularity: .month)) &&
            (query.isEmpty || "\(item.payee) \(item.detail) \(item.memo) \(item.category)".localizedCaseInsensitiveContains(query))
        }
    }
    var body: some View {
        List {
            Section { FreeUsageView(title: "経費", count: expenses.count) }
            Section {
                Toggle("すべての月を表示", isOn: $allMonths)
                if !allMonths { DatePicker("対象月（日付の月を使用）", selection: $selectedMonth, displayedComponents: .date) }
                LabeledContent("表示中の経費合計", value: filtered.reduce(0) { $0 + $1.amount }.yen).font(.headline)
            } footer: { Text("対象月と検索条件に一致する記録の合計です。") }
            if filtered.isEmpty {
                ContentUnavailableView("該当する経費はありません", systemImage: "receipt", description: Text("記録を追加するか、対象月や検索条件を変更してください。"))
            }
            ForEach(filtered) { expense in
                NavigationLink { ExpenseForm(expense: expense) } label: {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Image(systemName: "receipt").foregroundStyle(.teal)
                            Text(expense.payee).font(.headline)
                            Spacer()
                            Text(expense.amount.yen).bold()
                        }
                        Text("\(expense.category) · \(expense.date.formatted(date: .abbreviated, time: .omitted))").font(.caption).foregroundStyle(.secondary)
                        Text(expense.detail).font(.subheadline).lineLimit(2)
                    }.padding(.vertical, 6)
                }
                .swipeActions { Button("削除", role: .destructive) { pendingDelete = expense } }
            }
        }.navigationTitle("経費管理")
            .searchable(text: $query, prompt: "支払先・内容・メモを検索")
            .toolbar { Button("追加", systemImage: "plus") { adding = true } }
            .sheet(isPresented: $adding) { NavigationStack { ExpenseForm() } }
            .confirmationDialog("この経費を削除しますか？", isPresented: Binding(get: { pendingDelete != nil }, set: { if !$0 { pendingDelete = nil } }), titleVisibility: .visible) {
                Button("削除", role: .destructive) {
                    guard let record = pendingDelete else { return }
                    do { try RecordService.delete(record, from: context) } catch { self.error = error.localizedDescription }
                    pendingDelete = nil
                }
                Button("キャンセル", role: .cancel) { pendingDelete = nil }
            }.saveError($error)
    }
}
struct ExpenseForm: View {
    @EnvironmentObject private var subscriptions: SubscriptionStore
    @Query private var allRecords: [Expense]
    @State private var showingPlans = false
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    var expense: Expense?
    @State private var loaded = false
    @State private var date = Date()
    @State private var category = "交通費"
    @State private var amount = ""
    @State private var payee = ""
    @State private var detail = ""
    @State private var memo = ""
    @State private var error: String?
    var body: some View {
        Form {
            Section("経費の情報") {
                DatePicker("日付", selection: $date, displayedComponents: .date)
                Picker("カテゴリー", selection: $category) { ForEach(["交通費", "通信費", "消耗品費", "会議費", "接待交際費", "外注費", "その他"], id: \.self) { Text($0) } }
                MoneyField(title: "金額（円）", text: $amount)
                TextField("支払先（必須）", text: $payee).accessibilityIdentifier("expensePayee")
                TextField("内容（必須）", text: $detail).accessibilityIdentifier("expenseDetail")
            }
            Section("メモ") { TextField("メモ", text: $memo, axis: .vertical).lineLimit(3...6) }
        }.navigationTitle(expense == nil ? "経費を登録" : "経費を編集").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("キャンセル") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        guard let amount = Input.number(amount) else { return }
                        guard expense != nil || subscriptions.canAdd(count: allRecords.count) else { showingPlans = true; return }
                        do {
                            if let expense {
                                expense.date = date; expense.category = category; expense.amount = amount
                                expense.payee = payee.trimmingCharacters(in: .whitespacesAndNewlines)
                                expense.detail = detail; expense.memo = memo
                                try RecordService.save(context)
                            } else {
                                try RecordService.add(Expense(date: date, category: category, amount: amount, payee: payee.trimmingCharacters(in: .whitespacesAndNewlines), detail: detail, memo: memo), to: context)
                            }
                            dismiss()
                        } catch { self.error = error.localizedDescription }
                    }.disabled((Input.number(amount) ?? 0) <= 0 || payee.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || detail.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }.onAppear {
                guard !loaded else { return }; loaded = true
                if let expense {
                    date = expense.date; category = expense.category; amount = String(expense.amount)
                    payee = expense.payee; detail = expense.detail; memo = expense.memo
                }
            }.saveError($error).sheet(isPresented: $showingPlans) { SubscriptionView() }
    }
}
