import SwiftUI
import SwiftData

@main struct SomuKeiriNaviApp: App {
    @StateObject private var subscriptions = SubscriptionStore()
    @Environment(\.scenePhase) private var scenePhase
    private let container: ModelContainer?
    init() {
        let schema = Schema([Employee.self, Expense.self, Payroll.self, ContractDraft.self])
        #if DEBUG
        let preview = ProcessInfo.processInfo.arguments.contains("--marketing-preview")
        let testing = preview || ProcessInfo.processInfo.arguments.contains("--ui-testing")
        #else
        let testing = false
        #endif
        container = try? ModelContainer(for: schema, configurations: [ModelConfiguration(isStoredInMemoryOnly: testing)])
        container?.mainContext.autosaveEnabled = false
        #if DEBUG
        if preview, let context = container?.mainContext {
            let now = Date()
            let employee = Employee(name: "山田 花子（サンプル）", employmentType: "正社員", payType: "月給", rate: 280000, joinedAt: now, memo: "掲載用の架空データ")
            context.insert(employee)
            context.insert(Employee(name: "佐藤 太郎（サンプル）", employmentType: "パート", payType: "時給", rate: 1500, joinedAt: now, memo: "掲載用の架空データ"))
            for (category, amount, payee, detail) in [("交通費", 2400.0, "鉄道（サンプル）", "取引先への往復交通費"), ("消耗品費", 5800.0, "文具店（サンプル）", "コピー用紙・ファイル"), ("通信費", 4800.0, "通信会社（サンプル）", "業務用回線の月額料金")] {
                context.insert(Expense(date: now, category: category, amount: amount, payee: payee, detail: detail, memo: "掲載用の架空データ"))
            }
            let result = PayrollCalculator.calculate(monthly: true, rate: 280000, hours: 160, overtime: 8, allowance: 10000, deduction: 0)
            context.insert(Payroll(employee: employee, month: now, rate: 280000, hours: 160, overtime: 8, allowance: 10000, deduction: 0, result: result))
            context.insert(ContractDraft(template: "業務委託契約書", company: "サンプル商事", counterparty: "サンプル制作", start: now, end: Calendar.current.date(byAdding: .month, value: 3, to: now)!, amount: 150000, detail: "Webサイト制作の基本情報（サンプル）"))
            try? context.save()
        }
        #endif
    }
    var body: some Scene {
        WindowGroup {
            if let container {
                RootView().modelContainer(container).environment(\.locale, Locale(identifier: "ja_JP"))
                    .environmentObject(subscriptions)
                    .task { await subscriptions.refreshEntitlements() }
                    .onChange(of: scenePhase) { _, phase in
                        if phase == .active { Task { await subscriptions.refreshEntitlements() } }
                    }
            } else {
                ContentUnavailableView("データを開けません", systemImage: "externaldrive.badge.exclamationmark", description: Text("アプリを終了して、もう一度起動してください。保存済みデータは削除しないでください。"))
            }
        }
    }
}
