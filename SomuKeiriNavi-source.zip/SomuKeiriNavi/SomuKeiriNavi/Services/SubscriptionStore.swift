import StoreKit
import SwiftUI

@MainActor final class SubscriptionStore: ObservableObject {
    static let monthlyID = "jp.prototype.somukeirinavi.v01.monthly"
    static let annualID = "jp.prototype.somukeirinavi.v01.annual"
    static let ids = [monthlyID, annualID]
    @Published private(set) var products: [Product] = []
    @Published private(set) var isSubscribed = false
    @Published private(set) var isLoading = false
    @Published private(set) var isPurchasing = false
    @Published var message: String?
    @Published private(set) var loadError: String?
    private var listener: Task<Void, Never>?

    init() {
        listener = Task { [weak self] in
            for await result in Transaction.updates {
                guard let self else { return }
                guard case .verified(let transaction) = result,
                      Self.ids.contains(transaction.productID) else { continue }
                await self.refreshEntitlements()
                await transaction.finish()
            }
        }
    }
    deinit { listener?.cancel() }

    func canAdd(count: Int) -> Bool { isSubscribed || count < 10 }

    func load() async {
        guard !isLoading else { return }
        isLoading = true
        loadError = nil
        defer { isLoading = false }
        await refreshEntitlements()
        do {
            let loaded = try await Product.products(for: Self.ids)
            products = Self.ids.compactMap { id in loaded.first { $0.id == id && $0.type == .autoRenewable } }
            if products.count != Self.ids.count {
                loadError = "料金情報を取得できませんでした。通信環境を確認して再読み込みしてください。準備中の商品は購入できません。"
            }
        } catch {
            loadError = "料金情報を取得できませんでした。時間をおいて再読み込みしてください。"
        }
    }

    func refreshEntitlements() async {
        var active = false
        // currentEntitlements includes an active subscription's billing grace period.
        for await result in Transaction.currentEntitlements {
            guard case .verified(let transaction) = result,
                  Self.ids.contains(transaction.productID),
                  transaction.revocationDate == nil, !transaction.isUpgraded else { continue }
            active = true
        }
        isSubscribed = active
    }

    func purchase(_ product: Product) async {
        guard !isPurchasing, products.contains(where: { $0.id == product.id }) else { return }
        isPurchasing = true
        defer { isPurchasing = false }
        do {
            switch try await product.purchase() {
            case .success(let result):
                guard case .verified(let transaction) = result else {
                    message = "購入の確認ができませんでした。購入の復元をお試しください。"
                    return
                }
                await refreshEntitlements()
                await transaction.finish()
                message = isSubscribed ? "定期購入が有効になりました。" : "購入状態を確認しています。購入の復元をお試しください。"
            case .pending: message = "購入の承認待ちです。承認後に利用状態が更新されます。"
            case .userCancelled: break
            @unknown default: message = "購入状態を確認できませんでした。購入の復元をお試しください。"
            }
        } catch { message = "購入を完了できませんでした。時間をおいてお試しください。" }
    }

    func restore() async {
        guard !isPurchasing else { return }
        isPurchasing = true
        defer { isPurchasing = false }
        do {
            try await AppStore.sync()
            await refreshEntitlements()
            message = isSubscribed ? "定期購入を復元しました。" : "有効な定期購入は見つかりませんでした。購入時のApple Accountをご確認ください。"
        } catch { message = "購入を復元できませんでした。通信環境をご確認ください。" }
    }
}
