import Foundation
import SwiftData

@MainActor enum RecordService {
    static func save(_ context: ModelContext) throws {
        do { try context.save() } catch { context.rollback(); throw error }
    }
    static func add<T: PersistentModel>(_ record: T, to context: ModelContext) throws {
        context.insert(record)
        try save(context)
    }
    static func delete<T: PersistentModel>(_ record: T, from context: ModelContext) throws {
        context.delete(record)
        try save(context)
    }
    static func savePayroll(_ record: Payroll, existing: [Payroll], context: ModelContext) throws {
        for previous in existing where previous.employeeID == record.employeeID && Calendar.current.isDate(previous.month, equalTo: record.month, toGranularity: .month) {
            context.delete(previous)
        }
        try add(record, to: context)
    }
}
