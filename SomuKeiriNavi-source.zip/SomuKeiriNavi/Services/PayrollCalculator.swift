import Foundation

struct PayrollResult {
    let base: Double
    let overtime: Double
    let allowance: Double
    let deduction: Double
    var total: Double { base + overtime + allowance - deduction }
}
enum PayrollCalculator {
    // Prototype policy: monthly salary uses entered scheduled hours as the hourly divisor.
    static func calculate(monthly: Bool, rate: Double, hours: Double, overtime: Double, allowance: Double, deduction: Double) -> PayrollResult {
        let hourly = monthly ? (hours > 0 ? rate / hours : 0) : rate
        return PayrollResult(base: monthly ? rate : rate * hours,
                             overtime: (hourly * overtime * 1.25).rounded(),
                             allowance: allowance, deduction: deduction)
    }
}
enum Input {
    static func number(_ value: String) -> Double? {
        let normalized = value.applyingTransform(.fullwidthToHalfwidth, reverse: false) ?? value
        guard let number = Double(normalized.replacingOccurrences(of: ",", with: "")), number.isFinite, number >= 0, number <= 1_000_000_000 else { return nil }
        return number
    }
}
extension Double {
    var yen: String { formatted(.currency(code: "JPY").precision(.fractionLength(0))) }
}
