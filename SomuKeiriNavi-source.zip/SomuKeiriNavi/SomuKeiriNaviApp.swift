import SwiftUI
import SwiftData

@main struct SomuKeiriNaviApp: App {
    private let container: ModelContainer?
    init() {
        let schema = Schema([Employee.self, Expense.self, Payroll.self, ContractDraft.self])
        let testing = ProcessInfo.processInfo.arguments.contains("--ui-testing")
        container = try? ModelContainer(for: schema, configurations: [ModelConfiguration(isStoredInMemoryOnly: testing)])
        container?.mainContext.autosaveEnabled = false
    }
    var body: some Scene {
        WindowGroup {
            if let container {
                RootView().modelContainer(container).environment(\.locale, Locale(identifier: "ja_JP"))
            } else {
                ContentUnavailableView("データを開けません", systemImage: "externaldrive.badge.exclamationmark", description: Text("アプリを終了して、もう一度起動してください。保存済みデータは削除しないでください。"))
            }
        }
    }
}
