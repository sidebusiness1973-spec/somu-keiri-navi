import XCTest
import StoreKitTest

final class PrototypeUITests: XCTestCase {
    @MainActor func testSubscriptionPurchaseRestoreAndExpiration() async throws {
        let configuration = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "SomuKeiriNavi", withExtension: "storekit"))
        let session = try SKTestSession(contentsOf: configuration)
        session.resetToDefaultState()
        session.clearTransactions()
        session.disableDialogs = true
        session.storefront = "JPN"
        defer { session.clearTransactions() }
        let app = XCUIApplication()
        app.launchArguments = ["--ui-testing"]
        for id in ["jp.prototype.somukeirinavi.v01.monthly", "jp.prototype.somukeirinavi.v01.annual"] {
            app.launch()
            XCTAssertTrue(app.navigationBars["総務経理ナビ"].waitForExistence(timeout: 20))
            app.buttons["料金プラン"].tap()
            let plan = app.buttons.matching(NSPredicate(format: "label CONTAINS %@", id.hasSuffix("annual") ? "年額プラン" : "月額プラン")).firstMatch
            if !plan.waitForExistence(timeout: 10) { app.swipeUp() }
            XCTAssertTrue(plan.waitForExistence(timeout: 10))
            plan.tap()
            app.swipeUp()
            let purchase = app.buttons.matching(NSPredicate(format: "label CONTAINS %@", "プランを購入")).firstMatch
            XCTAssertTrue(purchase.waitForExistence(timeout: 10))
            purchase.tap()
            let active = app.staticTexts["定期購入は有効です"]
            XCTAssertTrue(active.waitForExistence(timeout: 15))
            app.terminate(); app.launch()
            app.buttons["料金プラン"].tap()
            XCTAssertTrue(active.waitForExistence(timeout: 10))
            app.swipeUp()
            app.buttons["購入を復元"].tap()
            XCTAssertTrue(active.waitForExistence(timeout: 10))
            try session.expireSubscription(productIdentifier: id)
            app.terminate(); app.launch()
            app.buttons["料金プラン"].tap()
            XCTAssertTrue(app.staticTexts["プランを選ぶ"].waitForExistence(timeout: 10))
            XCTAssertFalse(active.exists)
            session.clearTransactions()
            app.terminate()
        }
    }

    @MainActor func testExpenseFreeLimitAndEditing() throws {
        let app = XCUIApplication()
        app.launchArguments = ["--ui-testing"]
        app.launch()
        XCTAssertTrue(app.navigationBars["総務経理ナビ"].waitForExistence(timeout: 20))
        app.tabBars.buttons["経費"].tap()
        for index in 1...10 {
            app.buttons["追加"].tap()
            let amount = app.textFields["金額（円）"]
            XCTAssertTrue(amount.waitForExistence(timeout: 5))
            amount.tap(); amount.typeText("1200")
            let payee = app.textFields["expensePayee"]
            payee.tap(); payee.typeText("Sample \(index)")
            let detail = app.textFields["expenseDetail"]
            detail.tap(); detail.typeText("Train fare")
            app.buttons["保存"].tap()
            XCTAssertTrue(app.navigationBars["経費管理"].waitForExistence(timeout: 5))
        }
        app.buttons["追加"].tap()
        app.textFields["金額（円）"].tap(); app.textFields["金額（円）"].typeText("900")
        app.textFields["expensePayee"].tap(); app.textFields["expensePayee"].typeText("Blocked eleventh")
        app.textFields["expenseDetail"].tap(); app.textFields["expenseDetail"].typeText("Sample")
        app.buttons["保存"].tap()
        XCTAssertTrue(app.navigationBars["料金プラン"].waitForExistence(timeout: 5))
        app.buttons["閉じる"].firstMatch.tap()
        app.buttons["キャンセル"].tap()
        let search = app.searchFields.firstMatch
        if !search.exists { app.swipeDown() }
        XCTAssertTrue(search.waitForExistence(timeout: 5))
        search.tap(); search.typeText("Sample 10")
        let record = app.staticTexts["Sample 10"]
        XCTAssertTrue(record.waitForExistence(timeout: 5))
        record.tap()
        XCTAssertTrue(app.navigationBars["経費を編集"].waitForExistence(timeout: 5))
        // Saving an unchanged existing record must remain available at the free limit.
        app.buttons["保存"].tap()
        XCTAssertTrue(app.navigationBars["経費管理"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.navigationBars["料金プラン"].exists)
    }
    @MainActor func testPrototypeFlow() throws {
        let app = XCUIApplication()
        app.launchArguments = ["--ui-testing"]
        app.launch()
        XCTAssertTrue(app.navigationBars["総務経理ナビ"].waitForExistence(timeout: 10))
        app.tabBars.buttons["従業員"].tap()
        app.buttons["追加"].tap()
        let name = app.textFields["employeeName"]
        name.tap(); name.typeText("Test Employee")
        let rate = app.textFields["基本給・時給（円）"]
        rate.tap(); rate.typeText("300000")
        app.buttons["保存"].tap()
        XCTAssertTrue(app.staticTexts["Test Employee"].waitForExistence(timeout: 5))
        app.tabBars.buttons["経費"].tap()
        app.buttons["追加"].tap()
        let amount = app.textFields["金額（円）"]
        amount.tap(); amount.typeText("1200")
        let payee = app.textFields["expensePayee"]
        payee.tap(); payee.typeText("Test Store")
        let detail = app.textFields["expenseDetail"]
        detail.tap(); detail.typeText("Train fare")
        app.buttons["保存"].tap()
        XCTAssertTrue(app.staticTexts["Test Store"].waitForExistence(timeout: 5))
        app.tabBars.buttons["給与"].tap()
        app.swipeUp()
        XCTAssertTrue(app.buttons["計算結果を保存"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "300,000")).firstMatch.exists)
        app.buttons["計算結果を保存"].tap()
        XCTAssertTrue(app.alerts["計算結果を保存しました"].waitForExistence(timeout: 5))
        app.alerts.buttons["OK"].tap()
        app.tabBars.buttons["契約"].tap()
        for title in ["業務委託契約書", "雇用契約書", "秘密保持契約書（NDA）", "簡易発注書"] {
            XCTAssertTrue(app.staticTexts[title].exists)
        }
        app.staticTexts["業務委託契約書"].tap()
        XCTAssertTrue(app.textFields["会社名（必須）"].waitForExistence(timeout: 5))
        app.tabBars.buttons["ホーム"].tap()
        XCTAssertTrue(app.navigationBars["総務経理ナビ"].exists)
    }
}
