import SwiftUI
import SwiftData

struct HomeView: View {
    @Binding var tab: Int
    @Query private var employees: [Employee]
    @Query private var expenses: [Expense]
    @Query private var payrolls: [Payroll]
    private func thisMonth(_ date: Date) -> Bool { Calendar.current.isDate(date, equalTo: Date(), toGranularity: .month) }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                VStack(alignment: .leading, spacing: 18) {
                    HStack {
                        Label("総務経理ナビ", systemImage: "square.stack.3d.up.fill").font(.subheadline.bold())
                        Spacer()
                        Text(Date(), format: .dateTime.year().month()).font(.caption)
                    }.foregroundStyle(.white.opacity(0.8))
                    Text("毎日の事務を、\nひとつに整える。")
                        .font(.system(.largeTitle, design: .rounded, weight: .bold))
                        .foregroundStyle(.white).accessibilityAddTraits(.isHeader)
                    Text("従業員・給与の試算・経費・契約情報。\n小さな記録を、見返せるかたちに。")
                        .font(.subheadline).foregroundStyle(.white.opacity(0.85))
                    HStack(spacing: 14) {
                        Image(systemName: "tray.full.fill").font(.system(size: 42))
                            .foregroundStyle(Color(red: 0.45, green: 0.90, blue: 0.80))
                            .frame(width: 76, height: 76)
                            .background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 20))
                        VStack(alignment: .leading, spacing: 4) {
                            Text("端末内にまとめて保存").font(.headline).foregroundStyle(.white)
                            Text("あとから、すぐに振り返る").font(.caption).foregroundStyle(.white.opacity(0.75))
                        }
                    }
                    Button { tab = 3 } label: {
                        HStack {
                            Image(systemName: "receipt")
                            Text("経費の記録をはじめる").fontWeight(.bold)
                            Spacer()
                            Image(systemName: "arrow.right")
                        }.padding(16)
                            .foregroundStyle(Color(red: 0.05, green: 0.20, blue: 0.24))
                            .background(Color(red: 0.45, green: 0.90, blue: 0.80), in: RoundedRectangle(cornerRadius: 16))
                    }.buttonStyle(.plain)
                }.padding(24)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(LinearGradient(colors: [Color(red: 0.06, green: 0.15, blue: 0.24), Color(red: 0.08, green: 0.29, blue: 0.33)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 28))
                Text("今月の記録").font(.title2.bold())
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 145))], spacing: 12) {
                    metric("給与予定額", value: payrolls.filter { thisMonth($0.month) }.reduce(0) { $0 + $1.total }.yen, icon: "yensign.circle", target: 2)
                    metric("経費", value: expenses.filter { thisMonth($0.date) }.reduce(0) { $0 + $1.amount }.yen, icon: "receipt", target: 3)
                    metric("従業員", value: "\(employees.count)人", icon: "person.2", target: 1)
                }
                Text("給与予定額は保存済みの概算の合計です。税金・社会保険料を自動計算するものではありません。")
                    .font(.caption).foregroundStyle(.secondary)
                Text("業務をはじめる").font(.title2.bold())
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 145))], spacing: 12) {
                    shortcut("従業員", subtitle: "登録と情報の確認", icon: "person.badge.plus", target: 1)
                    shortcut("給与を試算", subtitle: "支給予定額の概算", icon: "yensign.circle", target: 2)
                    shortcut("経費を記録", subtitle: "支払先・金額を整理", icon: "receipt", target: 3)
                    shortcut("契約情報", subtitle: "基本情報の下書き", icon: "doc.text", target: 4)
                }
                Text("データはこの端末内に保存されます。")
                    .font(.caption).foregroundStyle(.secondary)
            }.padding(20).frame(maxWidth: 1000).frame(maxWidth: .infinity)
        }.background(Color(.systemGroupedBackground)).navigationTitle("総務経理ナビ")
    }
    private func metric(_ title: String, value: String, icon: String, target: Int) -> some View {
        Button { tab = target } label: {
            VStack(alignment: .leading, spacing: 14) {
                Image(systemName: icon).font(.title2).foregroundStyle(.teal)
                Text(value).font(.title2.bold()).minimumScaleFactor(0.6).lineLimit(1)
                Text(title).font(.subheadline).foregroundStyle(.secondary)
            }.frame(maxWidth: .infinity, alignment: .leading).padding(18)
                .background(.background, in: RoundedRectangle(cornerRadius: 22))
        }.buttonStyle(.plain)
    }
    private func shortcut(_ title: String, subtitle: String, icon: String, target: Int) -> some View {
        Button { tab = target } label: {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    Image(systemName: icon).font(.title2).foregroundStyle(.teal)
                        .frame(width: 44, height: 44)
                        .background(.teal.opacity(0.1), in: RoundedRectangle(cornerRadius: 12))
                    Spacer()
                    Image(systemName: "arrow.up.right").font(.caption.bold()).foregroundStyle(.secondary)
                }
                Text(title).font(.headline)
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }.frame(maxWidth: .infinity, alignment: .leading).padding(18)
                .background(.background, in: RoundedRectangle(cornerRadius: 22))
        }.buttonStyle(.plain)
    }
}
