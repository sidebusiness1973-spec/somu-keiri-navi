import Foundation

func verify(_ label: String, _ condition: @autoclosure () -> Bool) {
    guard condition() else { fatalError("FAIL: \(label)") }
    print("PASS: \(label)")
}
let monthly = PayrollCalculator.calculate(monthly: true, rate: 300_000, hours: 160, overtime: 10, allowance: 5_000, deduction: 3_000)
verify("月給の基本給与", monthly.base == 300_000)
verify("月給の残業単価と円単位丸め", monthly.overtime == 23_438)
verify("月給の支給予定額", monthly.total == 325_438)
let hourly = PayrollCalculator.calculate(monthly: false, rate: 1_200, hours: 80, overtime: 4, allowance: 2_000, deduction: 500)
verify("時給の基本給与", hourly.base == 96_000)
verify("時給の残業分", hourly.overtime == 6_000)
verify("時給の支給予定額", hourly.total == 103_500)
verify("残業なし", PayrollCalculator.calculate(monthly: true, rate: 250_000, hours: 160, overtime: 0, allowance: 0, deduction: 0).total == 250_000)
verify("控除超過を負数として検出できる", PayrollCalculator.calculate(monthly: false, rate: 1000, hours: 1, overtime: 0, allowance: 0, deduction: 2000).total == -1000)
verify("負の入力を拒否", Input.number("-1") == nil)
verify("非数を拒否", Input.number("nan") == nil)
verify("無限大を拒否", Input.number("inf") == nil)
verify("空欄を拒否", Input.number("") == nil)
verify("文字を拒否", Input.number("abc") == nil)
verify("全角と桁区切り", Input.number("１，２００") == 1200)
verify("上限超過を拒否", Input.number("1000000001") == nil)
print("15 checks passed")
