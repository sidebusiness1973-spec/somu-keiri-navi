import XCTest

final class PrototypeUITests: XCTestCase {
    @MainActor func testPrototypeFlow() throws {
        let app = XCUIApplication()
        app.launchArguments = ["--ui-testing"]
        app.launch()
        XCTAssertTrue(app.navigationBars["総務経理ナビ"].waitForExistence(timeout: 10))
        app.tabBars.buttons["従業員"].tap()
        app.buttons["追加"].tap()
        let name = app.textFields["employeeName"]
        name.tap(); name.typeText("Test Employee")
        let rate = app.textFields["基本給・時給（円）"]
        rate.tap(); rate.typeText("300000")
        app.buttons["保存"].tap()
        XCTAssertTrue(app.staticTexts["Test Employee"].waitForExistence(timeout: 5))
        app.tabBars.buttons["経費"].tap()
        app.buttons["追加"].tap()
        let amount = app.textFields["金額（円）"]
        amount.tap(); amount.typeText("1200")
        let payee = app.textFields["expensePayee"]
        payee.tap(); payee.typeText("Test Store")
        let detail = app.textFields["expenseDetail"]
        detail.tap(); detail.typeText("Train fare")
        app.buttons["保存"].tap()
        XCTAssertTrue(app.staticTexts["Test Store"].waitForExistence(timeout: 5))
        app.tabBars.buttons["給与"].tap()
        app.swipeUp()
        XCTAssertTrue(app.buttons["計算結果を保存"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "300,000")).firstMatch.exists)
        app.buttons["計算結果を保存"].tap()
        XCTAssertTrue(app.alerts["計算結果を保存しました"].waitForExistence(timeout: 5))
        app.alerts.buttons["OK"].tap()
        app.tabBars.buttons["契約"].tap()
        for title in ["業務委託契約書", "雇用契約書", "秘密保持契約書（NDA）", "簡易発注書"] {
            XCTAssertTrue(app.staticTexts[title].exists)
        }
        app.staticTexts["業務委託契約書"].tap()
        XCTAssertTrue(app.textFields["会社名（必須）"].waitForExistence(timeout: 5))
        app.tabBars.buttons["ホーム"].tap()
        XCTAssertTrue(app.navigationBars["総務経理ナビ"].exists)
    }
}
